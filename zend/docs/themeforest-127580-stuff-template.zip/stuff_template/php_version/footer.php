<?php
/**
 * @package Stuff_Template
 * @since Stuff 1.0
 */
?>
      </div>
      <!-- END CONTENT -->

      <!-- BEGIN LOADER -->
      <div id="loader"></div>
      <!-- END LOADER -->

    </div>
    <!-- END WRAPPER -->

  </body>
  <!-- END BODY -->

</html>