/*   
Theme Name: Stuff
Scheme Name: Dark Pink
*/

// -----------------------------------------------------------------------------

cufon_replace = [
  {selector: '.box .more', options: {color: '-linear-gradient(0.2=#ff2a81, 0.75=#e20080)', hover: {color: '#ff2a81'}}},
  {selector: 'form .submit', options: {color: '-linear-gradient(0.2=#ff2a81, 0.75=#e20080)'}}
];