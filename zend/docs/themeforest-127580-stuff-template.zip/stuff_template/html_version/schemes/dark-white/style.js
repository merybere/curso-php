/*   
Theme Name: Stuff
Scheme Name: Dark White
*/

// -----------------------------------------------------------------------------

cufon_replace = [
  {selector: '.box .more', options: {color: '-linear-gradient(0.2=#fff, 0.75=#c5c5c5)', hover: {color: '#fff'}}},
  {selector: 'form .submit', options: {color: '-linear-gradient(0.2=#fff, 0.75=#c5c5c5)'}}
];