/*   
Theme Name: Stuff
Scheme Name: Dark Green
*/

// -----------------------------------------------------------------------------

cufon_replace = [
  {selector: '.box .more', options: {color: '-linear-gradient(0.2=#52e827, 0.75=#00890a)', hover: {color: '#52e827'}}},
  {selector: 'form .submit', options: {color: '-linear-gradient(0.2=#52e827, 0.75=#00890a)'}}
];