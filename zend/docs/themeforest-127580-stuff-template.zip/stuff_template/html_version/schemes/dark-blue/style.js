/*   
Theme Name: Stuff
Scheme Name: Dark Blue
*/

// -----------------------------------------------------------------------------

cufon_replace = [
  {selector: '.box .more', options: {color: '-linear-gradient(0.2=#00cbe2, 0.75=#29c6ff)', hover: {color: '#00cbe2'}}},
  {selector: 'form .submit', options: {color: '-linear-gradient(0.2=#00cbe2, 0.75=#29c6ff)'}}
];