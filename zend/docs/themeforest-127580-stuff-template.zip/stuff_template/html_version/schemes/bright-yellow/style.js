/*   
Theme Name: Stuff
Scheme Name: Bright Yellow
*/

// -----------------------------------------------------------------------------

cufon_replace = [
  {selector: '.box .more', options: {color: '-linear-gradient(0.2=#f9a108, 0.75=#ff9c28)', hover: {color: '#f9a108'}}},
  {selector: 'form .submit', options: {color: '-linear-gradient(0.2=#f9a108, 0.75=#ff9c28)'}}
];