/*   
Theme Name: Stuff
Scheme Name: Bright Green
*/

// -----------------------------------------------------------------------------

cufon_replace = [
  {selector: '.box .more', options: {color: '-linear-gradient(0.2=#049128, 0.75=#153f14)', hover: {color: '#049128'}}},
  {selector: 'form .submit', options: {color: '-linear-gradient(0.2=#049128, 0.75=#153f14)'}}
];