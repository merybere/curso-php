/*   
Theme Name: Stuff
Scheme Name: Dark Yellow
*/

// -----------------------------------------------------------------------------

cufon_replace = [
  {selector: '.box .more', options: {color: '-linear-gradient(0.2=#ffef2a, 0.75=#e2ac00)', hover: {color: '#ffef2a'}}},
  {selector: 'form .submit', options: {color: '-linear-gradient(0.2=#ffef2a, 0.75=#e2ac00)'}}
];