/*   
Theme Name: Stuff
Scheme Name: Bright Pink
*/

// -----------------------------------------------------------------------------

cufon_replace = [
  {selector: '.box .more', options: {color: '-linear-gradient(0.2=#ff1499, 0.75=#d6177a)', hover: {color: '#ff1499'}}},
  {selector: 'form .submit', options: {color: '-linear-gradient(0.2=#ff1499, 0.75=#d6177a)'}}
];