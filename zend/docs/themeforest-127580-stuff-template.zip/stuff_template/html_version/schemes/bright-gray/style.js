/*   
Theme Name: Stuff
Scheme Name: Bright Gray
*/

// -----------------------------------------------------------------------------

cufon_replace = [
  {selector: '.box .more', options: {color: '-linear-gradient(0.2=#5d5d5d, 0.75=#2b2b2b)', hover: {color: '#5d5d5d'}}},
  {selector: 'form .submit', options: {color: '-linear-gradient(0.2=#5d5d5d, 0.75=#2b2b2b)'}}
];