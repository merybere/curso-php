/*   
Theme Name: Stuff
Scheme Name: Bright Red
*/

// -----------------------------------------------------------------------------

cufon_replace = [
  {selector: '.box .more', options: {color: '-linear-gradient(0.2=#ef6b23, 0.75=#e04a00)', hover: {color: '#ef6b23'}}},
  {selector: 'form .submit', options: {color: '-linear-gradient(0.2=#f52323, 0.75=#a60000)'}}
];