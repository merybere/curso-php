/*   
Theme Name: Stuff
Scheme Name: Bright Blue
*/

// -----------------------------------------------------------------------------

cufon_replace = [
  {selector: '.box .more', options: {color: '-linear-gradient(0.2=#1789a9, 0.75=#135c8a)', hover: {color: '#1787a8'}}},
  {selector: 'form .submit', options: {color: '-linear-gradient(0.2=#1a6bb7, 0.75=#2e4293)'}}
];